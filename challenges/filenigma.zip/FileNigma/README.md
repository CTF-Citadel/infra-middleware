# FileNigma

Introduction:
```
"We've stumbled upon a cluster of files, and hidden within it lies the flag. Can you uncover its location?
```

Flag Format:
```
TH{UUID}
```
